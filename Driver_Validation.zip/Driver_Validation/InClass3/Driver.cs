﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace InClass3
{
      internal class Driver
    {
        //driver class for validation
      private  string errorMessage = "";

        private string name;
        private string dob;
        private string hight;
        private string licnumber;
       public Driver(string name,string dob,string hight,string lic_num) 
        {
            //Constrictor for assigning the value for variables and checking it is empty or mot?
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException("Name cannot be null or empty.");
            }
           else if (string.IsNullOrEmpty(dob))
            {
                throw new ArgumentNullException("Date of birth cannot be null or empty.");
            }
          else  if (string.IsNullOrEmpty(hight))
            {
                throw new ArgumentNullException("Height cannot be null or empty.");
            }
            else if (string.IsNullOrEmpty(lic_num))
            {
                throw new ArgumentNullException("License number cannot be null or empty.");
            }
            
           

            this.name = name;
            this.dob = dob;
            this.hight = hight;
            this.licnumber = lic_num;
        }

        public string ValidateDriver()
        {

            if (errorMessage == "")
            {
                // Validate name (only allow characters and spaces)
                if (!Regex.IsMatch(name, @"^[a-zA-Z\s]+$"))
                {
                    errorMessage += "Name can only contain alphabetic characters and spaces.\n";
                }

                // Validate date of birth (dd/mm/yyyy)
                if (!Regex.IsMatch(dob, @"^\d{2}/\d{2}/\d{4}$"))
                {
                    errorMessage += "Date of birth must be in the format dd/mm/yyyy.\n";
                }

                // Validate height (only allow numbers)
                if (!Regex.IsMatch(hight, @"^\d+$"))
                {
                    errorMessage += "Height can only contain numbers.\n";
                }

                // Validate license number (1 leading alpha character followed by 14 digits)
                if (!Regex.IsMatch(licnumber, @"^[a-zA-Z]\d{5}-\d{5}-\d{4}$"))
                {
                    errorMessage += "License number must start with an alphabetic character followed by 14 digits.\n";
                }
            }
            return errorMessage;

        }

    }
}
