namespace InClass3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //try catch for cath the exeption
            try
            {
                string error;
                Driver d= new Driver(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text);
                error = d.ValidateDriver();//storing the error message if it occuers
                if(string.IsNullOrEmpty(error))
                {
                    label1.Text = "VALID DRIVER";
                    label1.ForeColor= Color.Green;
                }
                else
                {
                    label1.Text = error;
                    label1.ForeColor= Color.Red;
                }
                
            }
            catch(ArgumentNullException ex)
            {
                //catching the exptions
                label1.Text=ex.Message;
                label1.ForeColor= Color.Red;
            }
            

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}